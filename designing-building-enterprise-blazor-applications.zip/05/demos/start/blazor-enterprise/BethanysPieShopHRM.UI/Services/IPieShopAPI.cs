﻿namespace BethanysPieShopHRM.UI.Services
{
    internal interface IPieShopAPI
    {
    }
}