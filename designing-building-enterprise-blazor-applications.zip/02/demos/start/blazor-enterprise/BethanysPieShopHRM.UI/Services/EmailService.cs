﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BethanysPieShopHRM.Shared;

namespace BethanysPieShopHRM.UI.Services
{
    public class EmailService : IEmailService
    {
        public void SendEmail(Email email)
        {
            // Todo: Send emails
        }
    }
}
